package com.edilson.app.activities;

import com.viksaa.sssplash.lib.activity.AwesomeSplash;
import com.viksaa.sssplash.lib.cnst.Flags;
import com.viksaa.sssplash.lib.model.ConfigSplash;
import com.edilson.app.R;
import com.edilson.app.activities.EdilsonActivity;
import android.content.Intent;

public class SplashActivity extends AwesomeSplash {
  @Override
  public void animationsFinished() {
    startActivity(new Intent(this, EdilsonActivity.class));
  }

  @Override
  public void initSplash(ConfigSplash configSplash) {
    configSplash.setLogoSplash(R.drawable.edilson_dias3);

    configSplash.setBackgroundColor(R.color.splash_background_color);

    configSplash.setAnimCircularRevealDuration(0);

    configSplash.setAnimLogoSplashDuration(0);

    configSplash.setAnimTitleDuration(0);

    configSplash.setTitleSplash(null);
  }
}
