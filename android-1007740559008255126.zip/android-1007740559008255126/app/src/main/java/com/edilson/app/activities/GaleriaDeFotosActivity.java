package com.edilson.app.activities;

import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.os.Bundle;
import android.os.Build;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import com.edilson.app.R;
import android.graphics.PorterDuff;
import android.content.Intent;
import com.edilson.app.activities.NoticiasActivity;
import com.edilson.app.activities.GaleriaDeFotosActivity;
import android.support.v7.widget.AppCompatImageView;
import uk.co.senab.photoview.PhotoViewAttacher;

public class GaleriaDeFotosActivity extends AppCompatActivity {
  public Toolbar appBar;

  public AppCompatImageView imageView1;

  PhotoViewAttacher imageView1Attacher;

  public AppCompatImageView imageView2;

  PhotoViewAttacher imageView2Attacher;

  public AppCompatImageView imageView3;

  PhotoViewAttacher imageView3Attacher;

  public AppCompatImageView imageView4;

  PhotoViewAttacher imageView4Attacher;

  public AppCompatImageView imageView5;

  PhotoViewAttacher imageView5Attacher;

  public AppCompatImageView imageView6;

  PhotoViewAttacher imageView6Attacher;

  public AppCompatImageView imageView7;

  PhotoViewAttacher imageView7Attacher;

  public AppCompatImageView imageView8;

  PhotoViewAttacher imageView8Attacher;

  public LinearLayout mMainLayout;

  public GaleriaDeFotosActivity getContext() {
    return this;
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
  }

  @Override
  public void onBackPressed() {
    super.onBackPressed();
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.galeriade_fotos);

    mMainLayout = (LinearLayout) findViewById(R.id.galeriade_fotos);

    this.setup();
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
  }

  @Override
  protected void onPause() {
    super.onPause();
  }

  @Override
  protected void onResume() {
    super.onResume();

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      getWindow().setStatusBarColor(Color.parseColor("#FF2626A3"));
    }
  }

  @Override
  protected void onStart() {
    super.onStart();
  }

  @Override
  protected void onStop() {
    super.onStop();
  }

  private void setup() {
    appBar = (Toolbar) findViewById(R.id.app_bar3);

    GaleriaDeFotosActivity.this.setSupportActionBar(appBar);

    for (int i = 0; i < appBar.getChildCount(); ++i) {
      View child = appBar.getChildAt(i);
      if (child instanceof TextView) {
        child.setBackgroundColor(Color.TRANSPARENT);
        break;
      }
    }

    appBar.setNavigationIcon(
        ContextCompat.getDrawable(
            getContext(), R.drawable.android_app_bar_menu_icon_96x96_ffffffff));

    appBar
        .getNavigationIcon()
        .mutate()
        .setColorFilter(Color.parseColor("#FFFFFFFF"), PorterDuff.Mode.SRC_ATOP);

    appBar.setNavigationOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            GaleriaDeFotosActivity activity = GaleriaDeFotosActivity.this;
            Intent transitionIntent = new Intent(activity, NoticiasActivity.class);
            activity.startActivity(transitionIntent);
            activity.overridePendingTransition(
                android.R.anim.slide_in_left, android.R.anim.slide_out_right);
          }
        });

    imageView1 = (AppCompatImageView) findViewById(R.id.image_view1);

    imageView1Attacher = new PhotoViewAttacher(imageView1);

    imageView2 = (AppCompatImageView) findViewById(R.id.image_view2);

    imageView2Attacher = new PhotoViewAttacher(imageView2);

    imageView3 = (AppCompatImageView) findViewById(R.id.image_view3);

    imageView3Attacher = new PhotoViewAttacher(imageView3);

    imageView4 = (AppCompatImageView) findViewById(R.id.image_view4);

    imageView4Attacher = new PhotoViewAttacher(imageView4);

    imageView5 = (AppCompatImageView) findViewById(R.id.image_view5);

    imageView5Attacher = new PhotoViewAttacher(imageView5);

    imageView6 = (AppCompatImageView) findViewById(R.id.image_view6);

    imageView6Attacher = new PhotoViewAttacher(imageView6);

    imageView7 = (AppCompatImageView) findViewById(R.id.image_view7);

    imageView7Attacher = new PhotoViewAttacher(imageView7);

    imageView8 = (AppCompatImageView) findViewById(R.id.image_view8);

    imageView8Attacher = new PhotoViewAttacher(imageView8);
  }
}
