package com.edilson.app.activities;

import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.os.Bundle;
import android.os.Build;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import com.edilson.app.R;
import android.graphics.PorterDuff;
import com.edilson.app.activities.EdilsonActivity;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextWatcher;
import android.content.Intent;
import android.net.Uri;
import com.edilson.app.Application;
import com.edilson.app.activities.InformeActivity;
import android.text.Editable;
import android.support.v7.widget.AppCompatImageView;
import uk.co.senab.photoview.PhotoViewAttacher;

public class InformeActivity extends AppCompatActivity {
  public Toolbar appBar;

  public AppCompatImageView imageView1;

  PhotoViewAttacher imageView1Attacher;

  public AppCompatImageView imageView2;

  PhotoViewAttacher imageView2Attacher;

  public LinearLayout mMainLayout;

  public AppCompatTextView textView1;

  public InformeActivity getContext() {
    return this;
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
  }

  @Override
  public void onBackPressed() {
    super.onBackPressed();
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.informe);

    mMainLayout = (LinearLayout) findViewById(R.id.informe);

    this.setup();
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
  }

  @Override
  protected void onPause() {
    super.onPause();
  }

  @Override
  protected void onResume() {
    super.onResume();

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      getWindow().setStatusBarColor(Color.parseColor("#FF000000"));
    }
  }

  @Override
  protected void onStart() {
    super.onStart();
  }

  @Override
  protected void onStop() {
    super.onStop();
  }

  private void setup() {
    appBar = (Toolbar) findViewById(R.id.app_bar2);

    InformeActivity.this.setSupportActionBar(appBar);

    for (int i = 0; i < appBar.getChildCount(); ++i) {
      View child = appBar.getChildAt(i);
      if (child instanceof TextView) {
        child.setBackgroundColor(Color.TRANSPARENT);
        break;
      }
    }

    appBar.setNavigationIcon(
        ContextCompat.getDrawable(
            getContext(), R.drawable.android_app_bar_menu_icon_96x96_ffffffff));

    appBar
        .getNavigationIcon()
        .mutate()
        .setColorFilter(Color.parseColor("#FFFFFFFF"), PorterDuff.Mode.SRC_ATOP);

    appBar.setNavigationOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            InformeActivity activity = InformeActivity.this;
            Intent transitionIntent = new Intent(activity, EdilsonActivity.class);
            activity.startActivity(transitionIntent);
            activity.overridePendingTransition(
                android.R.anim.slide_in_left, android.R.anim.slide_out_right);
          }
        });

    textView1 = (AppCompatTextView) findViewById(R.id.text_view1);

    textView1.addTextChangedListener(
        new TextWatcher() {
          @Override
          public void onTextChanged(CharSequence _value, int start, int before, int count) {
            String value = _value.toString();
            Uri uri =
                Uri.parse(
                    "sms:"
                        + String.valueOf(
                            (((Application.TypeConverters.toDouble(value)) != null)
                                ? (Application.TypeConverters.toDouble(value))
                                : Double.valueOf(0D))));
            Intent intent1 = new Intent(Intent.ACTION_VIEW, uri);
            intent1.putExtra(
                "sms_body",
                String.valueOf(
                    (((Application.TypeConverters.toFloat(
                                InformeActivity.this.textView1.getText().toString()))
                            != null)
                        ? (Application.TypeConverters.toFloat(
                            InformeActivity.this.textView1.getText().toString()))
                        : Float.valueOf(0F))));
            InformeActivity.this.startActivity(Intent.createChooser(intent1, "Send Text Message"));
          }

          @Override
          public void beforeTextChanged(CharSequence value, int start, int count, int after) {}

          @Override
          public void afterTextChanged(Editable s) {}
        });

    imageView1 = (AppCompatImageView) findViewById(R.id.image_view11);

    imageView1Attacher = new PhotoViewAttacher(imageView1);

    imageView2 = (AppCompatImageView) findViewById(R.id.image_view21);

    imageView2Attacher = new PhotoViewAttacher(imageView2);
  }
}
